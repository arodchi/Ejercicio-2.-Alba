package pruebas;

public class HolaMundo {

	public static void main(String[] args) {
		
		//Impreimimos el comentario Hola GiT!!
		System.out.println("Hola GiT!!"); 
	}

}