package ejercicio2;

import java.util.ArrayList;

public class DeckCards {
	public static void main(String[] args) {

		 // Definición de los palos y valores de las cartas en el mazo
		String[] suits = { "Spades", "Diamonds", "Club", "Heart" };
		String[] values = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };

		 // Crear un ArrayList para almacenar las cartas
		ArrayList<Card> deck = new ArrayList<Card>();

		// Llenar el mazo con todas las combinaciones posibles de palos y valores
		for (int i = 0; i < suits.length; i++) {
			for (int j = 0; j < values.length; j++) {
				Card card = new Card(suits[i], values[j]);
				deck.add(card);// Agregar la carta al mazo (ArrayList)
			}
		}

		 // Barajar el mazo utilizando un algoritmo de intercambio aleatorio
		for (int i = 0; i < deck.size(); i++) {
			int j = (int) Math.floor(Math.random() * i);
			 // Intercambia las cartas en las posiciones i y j
			Card tmp = deck.get(i); // Guardamos temporalmente la carta en la posición i
			deck.set(i, deck.get(j));  // Ponemos la carta en la posición j en la posición i
			deck.set(j, tmp);	// Colocamos la carta que estaba en la posición i en la posición j
		}

		 // Imprimir las primeras 5 cartas del mazo barajado
		for (int i = 0; i < 5; i++) {
			System.out.println(deck.get(i));
		}

	}

}