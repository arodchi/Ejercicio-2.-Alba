package ejercicio2;

public class Card {
	
	//El palo de la carta ("Spades", "Diamonds", "Club", "Heart" )
	public String suit;
	 // El valor de la carta ("Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" )
	public String value;
	
	
	public Card (String suit, String value) {
		this.suit = suit;	// Asigna el valor del palo a la carta
		this.value = value; // Asigna el valor de la carta
	}

	// Devuelve una cadena con el palo y el valor de la carta separados
	public String toString () {
		return (this.suit+"-"+this.value);
	}
}